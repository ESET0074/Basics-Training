﻿namespace Web_Api_Demo.Models
{
    public class Products
    {
        public int Id { get; set; }
        public string name { get; set; }
        public int price { get; set; }
    }
}
